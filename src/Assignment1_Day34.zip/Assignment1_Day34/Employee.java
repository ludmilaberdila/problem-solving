package Assignment1_Day34;

public class Employee {
     String name;
    int employeeID;
     int salary;

     public Employee( String name, int employeeID, int salary){
         this.name = name;
         this.employeeID = employeeID;
         this.salary = salary;

     }
}
