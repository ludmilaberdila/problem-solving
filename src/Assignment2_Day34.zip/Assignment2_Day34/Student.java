package Assignment2_Day34;

public class Student {
    String name;
    int studenID;

    public Student(String name, int studentID){
        this.name  = name;
        this.studenID = studentID;
    }
}
