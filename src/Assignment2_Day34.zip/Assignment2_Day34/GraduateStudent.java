package Assignment2_Day34;

public class GraduateStudent extends Student{

    public GraduateStudent(String name, int studentID){
        super(name, studentID);
    }
}
