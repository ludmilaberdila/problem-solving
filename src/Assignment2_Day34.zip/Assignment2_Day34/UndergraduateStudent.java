package Assignment2_Day34;

public class UndergraduateStudent extends Student{


    public UndergraduateStudent(String name, int studentID){
        super(name, studentID);
    }
}
