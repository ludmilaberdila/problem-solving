package Day_27;

public class NumberPlay {
    public static void main(String[] args) {
        /*Create a class called "NumberPlay" that contains a main method. Within the main method,
        create a variable of each primitive data type (byte, short, int, long, float, double, char, boolean)
         and assign a value to it.
        Then, create a variable of each corresponding wrapper class and initialize it with
        the corresponding primitive variable using auto-boxing.
        Finally, create a variable of each primitive type and assign it the value
        of the corresponding wrapper object using unboxing..
        For byte and Byte your code must look like this:

        byte byteValue = 10;
        Byte byteWrapper = byteValue;
        byte byteUnbox = byteWrapper.byteValue();  */

        byte b1 = 10;
        short s1 = 5;
        int i1 = 20;
        long l1 = 40;
        float f1 = 12.8f;
        double d1 = 2.5;
        char c1 = 'A';
        boolean bo1 = True;

         // auto box
        Byte bAuto = b1;
        Short sAuto = s1;
        Integer iAuto = i1;
        Long lAuto = l1;
        Float fAuto = f1;
        Double dAuto = d1;
        Character cAuto = c1;
        Boolean booAuto = bo1;

        //anboxing
        byte b2 = bAuto.byteValue();
        short s1 = sAuto.shortValue();
        int i1 = iAuto.intValue();
        long l1 = lAuto.longValue();
        float f1 = fAuto.floatValue();
        double d1 = dAuto.doubleValue();
        char c1 = cAuto.charValue();
        boolean bo1 = booAuto.booleanValue();

    }

}
