package Assignment_2_Day30;

public class Product {
    String name;
    double price;
    int quantity;

    public Product(String newName, double newPrice, int newQuantity){
        name = newName;
        price = newPrice;
        quantity = newQuantity;
    }
    void ShoppingCart(){

    }

}
