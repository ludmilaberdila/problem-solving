package Day25;

public class TestPerson {
    public static void main(String[] args) {
        Person p1 = new Person();
        p1.name = "Ana";
        p1.introduce();
        p1.displayTotalPersons();

        Person p2 = new Person();
        p2.name = "Adam";
        p2.introduce();
        p2.displayTotalPersons();

        Person p3 = new Person();
        p3.name = "Mark";
        p3.introduce();
        p3.displayTotalPersons();


    }
}
